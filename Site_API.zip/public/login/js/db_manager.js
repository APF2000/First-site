let db = [{username: 'arthurpfonseca@gmail.com', psswd: 'senha1234'}];

const _db = db;
export { _db as db };